/**
 * 
 */
/**
 * 
 */
module AnimalSaftey {
	requires java.desktop;
	requires java.sql;
}