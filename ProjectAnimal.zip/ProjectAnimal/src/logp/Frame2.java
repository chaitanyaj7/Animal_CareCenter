package logp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Frame2 extends JFrame implements ActionListener {
    JLabel background, ll;
    JMenuItem miHealthCheckup;
    JButton btnNewEntry, btnDisplayInfo;

    Frame2() {
        setTitle("ANIMAL SAFETY");
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        ImageIcon img = new ImageIcon("C:\\javap\\z2.jpg");
        Image scaledImage = img.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        background = new JLabel(scaledIcon);
        background.setBounds(0, 0, width, height);
        setContentPane(background);

        ll = new JLabel("Animal Safety", SwingConstants.CENTER);
        ll.setFont(new Font("Arial", Font.BOLD, 50));
        ll.setForeground(Color.DARK_GRAY  );
        int titleWidth = 600;
        int titleHeight = 100;
        ll.setBounds((width - titleWidth) / 2, 50, titleWidth, titleHeight);
        background.add(ll);

       
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Options");

     
        Font menuFont = new Font("Arial", Font.BOLD, 24);
        menu.setFont(menuFont);
        menuBar.setBackground(Color.LIGHT_GRAY); 

      
        miHealthCheckup = new JMenuItem("Health Checkup");
        miHealthCheckup.setFont(menuFont);
        miHealthCheckup.setMargin(new Insets(10, 20, 10, 20));
        miHealthCheckup.addActionListener(this);

        menu.add(miHealthCheckup);
        menuBar.add(menu);

        setJMenuBar(menuBar);

        int buttonWidth = 300, buttonHeight = 70;
        int centerX = width / 2 - buttonWidth / 2;
        int centerY = height / 2 - 50;
        int spacing = 30;

        btnNewEntry = new JButton("New Entry");
        btnDisplayInfo = new JButton("Display Info");

        btnNewEntry.setFont(new Font("Arial", Font.BOLD, 22));
        btnDisplayInfo.setFont(new Font("Arial", Font.BOLD, 22));

        btnNewEntry.setBounds(600, 250, 300, 70);
        btnDisplayInfo.setBounds(600,400, 300, 70);

        btnNewEntry.addActionListener(this);
        btnDisplayInfo.addActionListener(this);

        background.add(btnNewEntry);
        background.add(btnDisplayInfo);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnNewEntry) {
            new NewEntry();
        } else if (e.getSource() == miHealthCheckup) {
            new healthp2();
        } else if (e.getSource() == btnDisplayInfo) {
            new display2();
        }
    }

    public static void main(String[] args) {
        new Frame2();
    }
}
