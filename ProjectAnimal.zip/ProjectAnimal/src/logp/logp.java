package logp;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;

class logp extends JFrame implements ActionListener {
    JFrame f;
    JLabel l1, l2, l3, l4, background;
    JTextField t1;
    JPasswordField t2;
    JButton b1, b2;

    logp() {
     
        f = new JFrame("Animal Safety");
        f.setSize(500, 400);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null); 
     
       
        ImageIcon img = new ImageIcon("C:\\javap\\anm1.jpg"); 
        Image i2 = img.getImage().getScaledInstance(500, 400, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel background = new JLabel(i3);
        background.setBounds(0, 0, 500, 400); 
        f.add(background);

       
        l3 = new JLabel("Login Page");
        l3.setFont(new Font("Arial", Font.BOLD, 22));
        l3.setHorizontalAlignment(JLabel.CENTER);
        l3.setBounds(100, 20, 300, 40);
        background.add(l3);

   
        l1 = new JLabel("Username:");
        l1.setBounds(100, 100, 100, 30);
        background.add(l1);

        t1 = new JTextField();
        t1.setBounds(200, 100, 200, 30);
        background.add(t1);

       
        l2 = new JLabel("Password:");
        l2.setBounds(100, 150, 100, 30);
        background.add(l2);

        t2 = new JPasswordField();
        t2.setBounds(200, 150, 200, 30);
        background.add(t2);

    
        b1 = new JButton("Login");
        b1.setBounds(150, 220, 100, 40);
        b1.addActionListener(this);
        background.add(b1);

       
        b2 = new JButton("Signup");
        b2.setBounds(270, 220, 100, 40);
        b2.addActionListener(this);
        background.add(b2);

  
        l4 = new JLabel("");
        l4.setBounds(100, 270, 300, 30);
        l4.setForeground(Color.RED);
        background.add(l4);

        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) { 
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Login", "root", "");

                String sql = "SELECT * FROM Login WHERE username=? AND password=?";
                PreparedStatement st = con.prepareStatement(sql);

                st.setString(1, t1.getText());
                st.setString(2, new String(t2.getPassword()));

                ResultSet rs = st.executeQuery();    
                 
                if (rs.next()) {


                    f.dispose(); 
                    new Frame2(); 
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Username or Password!");
                }

                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database Connection Error!");
            }
        } else if (e.getSource() == b2) { 
            f.dispose(); 
            new Signup().setVisible(true); 
        }
    }

    public static void main(String[] args) {
        new logp();
    }
}
