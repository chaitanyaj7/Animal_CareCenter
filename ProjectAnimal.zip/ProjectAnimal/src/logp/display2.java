package logp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

class display2 extends JFrame implements ActionListener {
    JLabel[] labels;
    JLabel[] values;
    JTextField t1;
    JButton b1, b2;
    JPanel panel;

    display2() {
        setTitle("Animal Health Checkup");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);  
        setLocationRelativeTo(null);

        panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(240, 248, 255));

        JLabel header = new JLabel("Animal Health Checkup", JLabel.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 22));
        header.setForeground(Color.DARK_GRAY);
        header.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panel.add(header, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());
        inputPanel.setBackground(new Color(200, 220, 240));

        JLabel l1 = new JLabel("Enter Animal ID:");
        l1.setFont(new Font("Arial", Font.PLAIN, 14));
        t1 = new JTextField(10);
        b2 = new JButton("Show");
        b2.addActionListener(this);
        b1 = new JButton("Back");
        b1.addActionListener(this);

        inputPanel.add(l1);
        inputPanel.add(t1);
        inputPanel.add(b2);
        inputPanel.add(b1);

        panel.add(inputPanel, BorderLayout.CENTER);

        JPanel dataPanel = new JPanel();
        dataPanel.setLayout(new GridLayout(16, 2, 10, 10));
        dataPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        dataPanel.setBackground(new Color(255, 255, 255));

        String[] labelTexts = {"Animal ID:", "Species:", "Age:", "Weight:", "Breed:", "Temperature:", 
                               "Heart Rate:", "Respiration Rate:", "Body Condition:", "Coat & Skin Condition:", 
                               "Hydration Level:", "Gender:", "Admit Date:", "Vaccination:", "Disease:", "Disease Name:"};
        labels = new JLabel[labelTexts.length];
        values = new JLabel[labelTexts.length];

        for (int i = 0; i < labelTexts.length; i++) {
            labels[i] = new JLabel(labelTexts[i]);
            labels[i].setFont(new Font("Arial", Font.BOLD, 14));
            labels[i].setForeground(Color.BLACK);

            values[i] = new JLabel("N/A");
            values[i].setFont(new Font("Arial", Font.PLAIN, 14));
            values[i].setForeground(Color.BLUE);

            dataPanel.add(labels[i]);
            dataPanel.add(values[i]);
        }

        JScrollPane scrollPane = new JScrollPane(dataPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panel.add(scrollPane, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            this.dispose();
        } else if (e.getSource() == b2) {
            fetchAnimalDetails();
        }
    }

    private void fetchAnimalDetails() {
        String animalID = t1.getText().trim();

        if (animalID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an Animal ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AnimalData1", "root", "");
            String query = "SELECT * FROM AnimalInfo1 WHERE Animal_Id = ?";
            PreparedStatement pst = con.prepareStatement(query);

            try {
                pst.setInt(1, Integer.parseInt(animalID));
            } catch (NumberFormatException ex) {
                pst.setString(1, animalID);
            }

            ResultSet rs = pst.executeQuery();

            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(this, "No record found!", "Not Found", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (rs.next()) {
                values[0].setText(rs.getString("Animal_Id"));
                values[1].setText(rs.getString("Species"));
                values[2].setText(rs.getString("Age"));
                values[3].setText(rs.getString("Weight"));
                values[4].setText(rs.getString("Breed"));
                values[5].setText(rs.getString("Temperature"));
                values[6].setText(rs.getString("Heart_Rate"));
                values[7].setText(rs.getString("Respiration_Rate"));
                values[8].setText(rs.getString("Body_Condition"));
                values[9].setText(rs.getString("Coat_Skin"));
                values[10].setText(rs.getString("Hydration_Level"));
                values[11].setText(rs.getString("Gender"));
                values[12].setText(rs.getString("Admit_Date"));
                values[13].setText(rs.getString("Vaccination"));
                values[14].setText(rs.getString("Disease"));
                values[15].setText(rs.getString("Disease_Name"));
            }

            rs.close();
            pst.close();
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new display2();
    }
}
