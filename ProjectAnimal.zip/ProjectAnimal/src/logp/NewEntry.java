package logp;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;

class NewEntry extends JFrame {
    private JTextField t1, t2, t3, t4;
    private JButton submitButton, backButton;
    private JComboBox<String> speciesComboBox;
    private JRadioButton maleRadio, femaleRadio;

    NewEntry() {
        setTitle("Animal Safety - New Entry");
        setSize(735, 490);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); 
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(Color.WHITE);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.GRAY);
        headerPanel.setBounds(0, 30, 1600, 80); 
        headerPanel.setLayout(null); 

        JPanel BottomrPanel = new JPanel();
        BottomrPanel.setBackground(Color.GRAY);
        BottomrPanel.setBounds(0, 700, 1600, 80); 
        BottomrPanel.setLayout(null);
        add(BottomrPanel);
        
        
        JLabel headerLabel = new JLabel("Animal Entry Form");
        headerLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setBounds(600, 25, 300, 30); 

        headerPanel.add(headerLabel);
        add(headerPanel);

        JLabel lblAnimalId = new JLabel("Animal ID/Name:");
        lblAnimalId.setBounds(500, 200, 200, 30);
        add(lblAnimalId);

        t1 = new JTextField();
        t1.setBounds(750, 200, 250, 30);
        t1.setBackground(Color.WHITE); 
        add(t1);

        JLabel lblSpecies = new JLabel("Species:");
        lblSpecies.setBounds(500, 250, 200, 30);
        add(lblSpecies);

        speciesComboBox = new JComboBox<>(new String[]{"Mammals", "Bird", "Reptile", "Amphibians"});
        speciesComboBox.setBounds(750, 250, 250, 30);
        speciesComboBox.setBackground(Color.WHITE); 
        add(speciesComboBox);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setBounds(500, 300, 200, 30);
        add(lblAge);

        t2 = new JTextField();
        t2.setBounds(750, 300, 250, 30);
        t2.setBackground(Color.WHITE);
        add(t2);

        JLabel lblWeight = new JLabel("Weight:");
        lblWeight.setBounds(500, 350, 200, 30);
        add(lblWeight);

        t3 = new JTextField();
        t3.setBounds(750, 350, 250, 30);
        t3.setBackground(Color.WHITE);
        add(t3);

        JLabel lblBreed = new JLabel("Breed (if applicable):");
        lblBreed.setBounds(500, 400, 200, 30);
        add(lblBreed);

        t4 = new JTextField();
        t4.setBounds(750, 400, 250, 30);
        t4.setBackground(Color.WHITE);
        add(t4);

        JLabel lblGender = new JLabel("Gender:");
        lblGender.setBounds(500, 450, 200, 30);
        add(lblGender);

        maleRadio = new JRadioButton("Male");
        femaleRadio = new JRadioButton("Female");
        maleRadio.setBounds(750, 450, 100, 30);
        femaleRadio.setBounds(850, 450, 120, 30);
        
        
        maleRadio.setBackground(Color.WHITE);
        femaleRadio.setBackground(Color.WHITE);

        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        add(maleRadio);
        add(femaleRadio);

        submitButton = new JButton("Submit");
        submitButton.setBounds(600, 500, 100, 40);
        submitButton.setBackground(new Color(0, 153, 76));
        submitButton.setForeground(Color.WHITE);
        add(submitButton);

        backButton = new JButton("Back");
        backButton.setBounds(750, 500, 100, 40);
        backButton.setBackground(Color.RED);
        backButton.setForeground(Color.WHITE);
        add(backButton);
        String imagePath = "C:\\javap\\d22 (1).jpg"; 
       
     
        ImageIcon c1 = new ImageIcon(imagePath);
        Image i1 = c1.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i1);
        JLabel l6 = new JLabel(i2);
        l6.setBounds(1000, 200, 300, 300);
        getContentPane().add(l6);

      
    
        setVisible(true);
        setLocationRelativeTo(null);

     
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AnimalData1", "root", "");
                    String query = "INSERT INTO AnimalInfo1 (Animal_Id, Species, Age, Weight, Breed, Gender, Temperature, Heart_Rate, Respiration_Rate, Body_Condition, Coat_Skin, Hydration_Level,Admit_Date, Vaccination, Disease, Disease_Name ) VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0,0,0,0,0)";
                    PreparedStatement pstmt = con.prepareStatement(query);
                    pstmt.setString(1, t1.getText());
                    pstmt.setString(2, (String) speciesComboBox.getSelectedItem());
                    pstmt.setString(3, t2.getText());
                    pstmt.setString(4, t3.getText());
                    pstmt.setString(5, t4.getText());
                    pstmt.setString(6, maleRadio.isSelected() ? "Male" : femaleRadio.isSelected() ? "Female" : "");

                    int result = pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, result > 0 ? "Animal Entry Submitted Successfully!" : "Insertion Failed!", "Status", JOptionPane.INFORMATION_MESSAGE);
                    t1.setText("");
                    t2.setText("");
                    t3.setText("");
                    t4.setText("");

                    
                    
                    pstmt.close();
                    con.close();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButton.addActionListener(e -> dispose());
    }

    public static void main(String[] args) {
        new NewEntry();
    }
}









