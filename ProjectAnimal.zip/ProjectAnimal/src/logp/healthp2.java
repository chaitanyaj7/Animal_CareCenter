package logp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class healthp2 extends JFrame implements ActionListener {

    JButton b1, b2, b3, backButton;
    JLabel background;

    healthp2() {
        
        setTitle("ANIMAL SAFETY");
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

       
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int frameWidth = screenSize.width;
        int frameHeight = screenSize.height;

        
        ImageIcon img = new ImageIcon("C:\\javap\\a5.jpg");
        Image i2 = img.getImage().getScaledInstance(frameWidth, frameHeight, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        background = new JLabel(i3);
        background.setBounds(0, 0, frameWidth, frameHeight);

       
        int buttonWidth = 300;
        int buttonHeight = 70;
        int spacing = 20; 

       
        int centerX = (frameWidth - buttonWidth) / 2;
        int startY = frameHeight / 3;

        
        b1 = new JButton("Insert Entry");
        b2 = new JButton("Update Entry");
        b3 = new JButton("Delete Entry");

      
        b1.setBounds(600,300 , buttonWidth, buttonHeight);
        b2.setBounds(600, 400, buttonWidth, buttonHeight);
        b3.setBounds(600, 500, buttonWidth, buttonHeight);

        
        backButton = new JButton("🔙");
        backButton.setBounds(30, frameHeight - 80, 50, 40);
        backButton.addActionListener(this);

       
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);

        
        add(b1);
        add(b2);
        add(b3);
        add(backButton);
        add(background); 

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            new HealthInsert(); 
            dispose();
        } else if (e.getSource() == b2) {
            new UpdateInfo();
            dispose();
        } else if (e.getSource() == b3) {
            new DeleteInfo();
        } else if (e.getSource() == backButton) {
            dispose(); 
        }
    }

    public static void main(String[] args) {
        new healthp2();
    }
}
