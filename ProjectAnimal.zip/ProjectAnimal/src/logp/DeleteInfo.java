package logp;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteInfo implements ActionListener {

    JFrame f;
    JPanel panel;
    JLabel titleLabel, idLabel;
    JTextField idField;
    JButton deleteButton, exitButton;

    DeleteInfo() {
        int frameWidth = 735, frameHeight = 490;

       
        f = new JFrame("Delete Animal Record");
        f.setSize(frameWidth, frameHeight);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(new BorderLayout());

       
        panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255)); 
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        
        titleLabel = new JLabel("Delete Animal Record");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 51, 102)); 
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(titleLabel, gbc);

      
        idLabel = new JLabel("Animal ID:");
        idLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        panel.add(idLabel, gbc);

        
        idField = new JTextField(15);
        idField.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(idField, gbc);

        
        deleteButton = new JButton("Delete");
        deleteButton.setBackground(new Color(220, 20, 60)); 
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFont(new Font("Arial", Font.BOLD, 16));
        deleteButton.addActionListener(this);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(deleteButton, gbc);

        
        exitButton = new JButton("Exit");
        exitButton.setBackground(new Color(105, 105, 105)); 
        exitButton.setForeground(Color.WHITE);
        exitButton.setFont(new Font("Arial", Font.BOLD, 16));
        exitButton.addActionListener(this);
        gbc.gridx = 1;
        panel.add(exitButton, gbc);

       
        f.add(panel, BorderLayout.CENTER);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == deleteButton) {
            deleteAnimal();
        } else if (e.getSource() == exitButton) {
            f.dispose();
        }
    }

    private void deleteAnimal() {
        String animalId = idField.getText().trim();

        if (animalId.isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please enter an Animal ID!", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AnimalData1", "root", "");
             PreparedStatement pst = con.prepareStatement("DELETE FROM AnimalInfo1 WHERE Animal_Id=?")) {

            pst.setString(1, animalId);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(f, "Animal record deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(f, "Animal ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(f, "Database Error!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new DeleteInfo();
    }
}
