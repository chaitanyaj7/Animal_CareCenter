package logp;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

import logp.UpdateInfo;

class UpdateInfo extends JFrame implements ActionListener {
    JFrame f;
    JLabel heading, l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16,background;
    JTextField t1, t2, t3, t4, t5, t6, t7, t8, t9, tDiseaseName;
    JComboBox<String> cb, cbBodyCondition, cbCoatCondition;
    JRadioButton r1, r2, rVacYes, rVacNo, rDisYes, rDisNo;
    JButton submit1, backButton;
    JPanel panel;
    
    UpdateInfo() {
        f = new JFrame("Animal Safety - Update Information");
        f.setSize(800, 850);
        f.setLayout(null);
        f.setLocationRelativeTo(null);
        f.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
       
        
        panel = new JPanel();
        panel.setBackground(new Color(128, 128, 128)); 
        panel.setBounds(0, 20, 1600, 60);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER));
        
        heading = new JLabel("Update Information");
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(heading);
        f.add(panel);
        
        tDiseaseName = new JTextField();
        tDiseaseName.setBounds(700, 690, 400, 30);
        tDiseaseName.setVisible(false);
        f.add(tDiseaseName);

        l1 = new JLabel("Animal Id/Name");
        l1.setBounds(500, 90, 200, 30);
        f.add(l1);
        
        l2 = new JLabel("Species");
        l2.setBounds(500, 130, 200, 30);
        f.add(l2);
        
        l3 = new JLabel("Age");
        l3.setBounds(500, 170, 200, 30);
        f.add(l3);
        
        l4 = new JLabel("Weight");
        l4.setBounds(500, 210, 200, 30);
        f.add(l4);
        
        l5 = new JLabel("Breed");
        l5.setBounds(500, 250, 200, 30);
        f.add(l5);
        
        l6 = new JLabel("Gender");
        l6.setBounds(500, 290, 200, 30);
        f.add(l6);
        
        l7 = new JLabel("Temperature");
        l7.setBounds(500, 330, 200, 30);
        f.add(l7);
        
        l8 = new JLabel("Heart Rate");
        l8.setBounds(500, 370, 200, 30);
        f.add(l8);
        
        l9 = new JLabel("Respiration Rate");
        l9.setBounds(500, 410, 200, 30);
        f.add(l9);
        
        l10 = new JLabel("Body Condition");
        l10.setBounds(500, 450, 200, 30);
        f.add(l10);
        
        l11 = new JLabel("Coat & Skin Condition");
        l11.setBounds(500, 490, 200, 30);
        f.add(l11);
        
        l12 = new JLabel("Hydration Level");
        l12.setBounds(500, 530, 200, 30);
        f.add(l12);
        
        l13 = new JLabel("Admit Date (YYYY-MM-DD)");
        l13.setBounds(500, 570, 200, 30);
        f.add(l13);
        
        l14 = new JLabel("Vaccination");
        l14.setBounds(500, 610, 200, 30);
        f.add(l14);
        
        l15 = new JLabel("Disease");
        l15.setBounds(500, 650, 200, 30);
        f.add(l15);
        
        l16 = new JLabel("Disease Name");
        l16.setBounds(500, 690, 200, 30);
        f.add(l16);
        l16.setVisible(false);
        
   
        t1 = new JTextField();
        t1.setBounds(700, 90, 400, 30);
        f.add(t1);
        
        String[] species = {"Mammals", "Bird", "Reptile", "Amphibians"};
        cb = new JComboBox<>(species);
        cb.setBounds(700, 130, 400, 30);
        f.add(cb);
        
        t2 = new JTextField();
        t2.setBounds(700, 170, 400, 30);
        f.add(t2);
        
        t3 = new JTextField();
        t3.setBounds(700, 210, 400, 30);
        f.add(t3);
        
        t4 = new JTextField();
        t4.setBounds(700, 250, 400, 30);
        f.add(t4);
        
        t5 = new JTextField();
        t5.setBounds(700, 330, 400, 30);
        f.add(t5);

        t6 = new JTextField();
        t6.setBounds(700, 370, 400, 30);
        f.add(t6);

        t7 = new JTextField();
        t7.setBounds(700, 410, 400, 30);
        f.add(t7);

        t8 = new JTextField();
        t8.setBounds(700, 530, 400, 30);
        f.add(t8);
        
        String[] bodyConditions = {"Underweight", "Normal", "Overweight"};
        cbBodyCondition = new JComboBox<>(bodyConditions);
        cbBodyCondition.setBounds(700, 450, 400, 30);
        f.add(cbBodyCondition);


        String[] coatConditions = {"Healthy", "Dull Coat", "Skin Issues"};
        cbCoatCondition = new JComboBox<>(coatConditions);
        cbCoatCondition.setBounds(700, 490, 400, 30);
        f.add(cbCoatCondition);
        
        r1 = new JRadioButton("Male");
        r2 = new JRadioButton("Female");
        r1.setBounds(700, 290, 80, 30);
        r2.setBounds(800, 290, 80, 30);
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        f.add(r1);
        f.add(r2);
        
        t9 = new JTextField();
        t9.setBounds(700, 570, 400, 30);
        f.add(t9);
        
        rVacYes = new JRadioButton("Yes");
        rVacNo = new JRadioButton("No");
        rVacYes.setBounds(700, 610, 80, 30);
        rVacNo.setBounds(800, 610, 80, 30);
        ButtonGroup bgVac = new ButtonGroup();
        bgVac.add(rVacYes);
        bgVac.add(rVacNo);
        f.add(rVacYes);
        f.add(rVacNo);
        
        rDisYes = new JRadioButton("Yes");
        rDisNo = new JRadioButton("No");
        rDisYes.setBounds(700, 650, 80, 30);
        rDisNo.setBounds(800, 650, 80, 30);
        
        
        rDisYes.addActionListener(e -> {
            l16.setVisible(true);
            tDiseaseName.setVisible(true);
        });

        rDisNo.addActionListener(e -> {
            l16.setVisible(false);
            tDiseaseName.setVisible(false);
        });

        ButtonGroup bgDis = new ButtonGroup();
        bgDis.add(rDisYes);
        bgDis.add(rDisNo);
        f.add(rDisYes);
        f.add(rDisNo);
        
        submit1 = new JButton("Submit");
        submit1.setBounds(600, 750, 150, 55);
        submit1.setBackground(Color.GREEN);
        submit1.setForeground(Color.WHITE);
        f.add(submit1);
        
        backButton = new JButton("Back");
        backButton.setBounds(850, 750, 150, 55);
        backButton.setBackground(Color.RED);
        backButton.setForeground(Color.WHITE);
        f.add(backButton);
        backButton.addActionListener(this);

        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit1) {
            try {
            	 Connection   con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AnimalData1", "root", "");
                String uq = "UPDATE AnimalInfo1 SET Species=?, Age=?, Weight=?, Breed=?, Gender=?, Temperature=?, Heart_Rate=?, Respiration_Rate=?, Body_Condition=?, Coat_Skin=?, Hydration_Level=? ,Admit_Date=?, Vaccination=?, Disease=?, Disease_Name=?WHERE Animal_Id=?";
                PreparedStatement ust = con.prepareStatement(uq);

                ust.setString(1, (String) cb.getSelectedItem());
                ust.setString(2, t2.getText().trim());
                ust.setString(3, t3.getText().trim());
                ust.setString(4, t4.getText().trim());
                ust.setString(5, r1.isSelected() ? "Male" : "Female");
                ust.setString(6, t5.getText().trim());
                ust.setString(7, t6.getText().trim());
                ust.setString(8, t7.getText().trim());
                ust.setString(9, (String) cbBodyCondition.getSelectedItem());
                ust.setString(10, (String) cbCoatCondition.getSelectedItem());
                ust.setString(11, t8.getText().trim());
                ust.setString(12, t1.getText().trim());

                int urt = ust.executeUpdate();
                JOptionPane.showMessageDialog(f, "Data Updated Successfully!");
                t1.setText("");
                t2.setText("");
                t3.setText("");
                t4.setText("");
                t5.setText("");
                t6.setText("");
                t7.setText("");
                t8.setText("");
                
                
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == backButton) {
            f.dispose();
            new healthp2 ();
        }
    }

    public static void main(String[] args) {
        new UpdateInfo();
    }
}
