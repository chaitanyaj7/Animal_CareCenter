   package logp;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.text.ParseException;

class HealthInsert implements ActionListener {
    JFrame frame;
    JPanel titlePanel;         
    JLabel lblTitle, lblAnimalId, lblTemperature, lblHeartRate, lblRespirationRate, lblBodyCondition, lblCoatSkin, lblHydrationLevel;
    JLabel lblAdmitDate, lblVaccination, lblDisease, lblDiseaseName;
    JTextField txtAnimalId, txtTemperature, txtHeartRate, txtRespirationRate, txtHydrationLevel, txtDiseaseName;
    JComboBox<String> cbBodyCondition, cbCoatSkin;
    JFormattedTextField txtAdmitDate;
    JRadioButton rbVaccYes, rbVaccNo, rbDiseaseYes, rbDiseaseNo;
    ButtonGroup bgVaccination, bgDisease;
    JButton btnSubmit, btnBack;

    HealthInsert() {
        frame = new JFrame("Animal Safety - Health Parameters");
        frame.setSize(800, 750); 
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setLocationRelativeTo(null);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        titlePanel = new JPanel();
        titlePanel.setBackground(new Color(76, 134, 168));
        titlePanel.setBounds(0, 30, 1600, 80);
        titlePanel.setLayout(null);

        lblTitle = new JLabel("Health Parameters");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(700, 20, 300, 40);
        titlePanel.add(lblTitle);
        frame.add(titlePanel);

        lblAnimalId = new JLabel("Animal ID:");
        lblAnimalId.setBounds(550, 120, 150, 30);
        frame.add(lblAnimalId);

        txtAnimalId = new JTextField();
        txtAnimalId.setBounds(750, 120, 300, 30);
        frame.add(txtAnimalId);

        lblTemperature = new JLabel("Temperature:");
        lblTemperature.setBounds(550, 170, 150, 30);
        frame.add(lblTemperature);

        txtTemperature = new JTextField();
        txtTemperature.setBounds(750, 170, 300, 30);
        frame.add(txtTemperature);

        lblHeartRate = new JLabel("Heart Rate:");
        lblHeartRate.setBounds(550, 220, 150, 30);
        frame.add(lblHeartRate);

        txtHeartRate = new JTextField();
        txtHeartRate.setBounds(750, 220, 300, 30);
        frame.add(txtHeartRate);

        lblRespirationRate = new JLabel("Respiration Rate:");
        lblRespirationRate.setBounds(550, 270, 150, 30);
        frame.add(lblRespirationRate);

        txtRespirationRate = new JTextField();
        txtRespirationRate.setBounds(750, 270, 300, 30);
        frame.add(txtRespirationRate);

        lblBodyCondition = new JLabel("Body Condition:");
        lblBodyCondition.setBounds(550, 320, 150, 30);
        frame.add(lblBodyCondition);

        cbBodyCondition = new JComboBox<>(new String[]{"Good", "Bad", "Medium"});
        cbBodyCondition.setBounds(750, 320, 300, 30);
        frame.add(cbBodyCondition);

        lblCoatSkin = new JLabel("Coat & Skin Condition:");
        lblCoatSkin.setBounds(550, 370, 150, 30);
        frame.add(lblCoatSkin);

        cbCoatSkin = new JComboBox<>(new String[]{"Good", "Bad", "Medium"});
        cbCoatSkin.setBounds(750, 370, 300, 30);
        frame.add(cbCoatSkin);

        lblHydrationLevel = new JLabel("Hydration Level:");
        lblHydrationLevel.setBounds(550, 420, 150, 30);
        frame.add(lblHydrationLevel);

        txtHydrationLevel = new JTextField();
        txtHydrationLevel.setBounds(750, 420, 300, 30);
        frame.add(txtHydrationLevel);

        lblAdmitDate = new JLabel("Admit Date (DD/MM/YYYY):");
        lblAdmitDate.setBounds(550, 470, 200, 30);
        frame.add(lblAdmitDate);

        try {
            MaskFormatter dateMask = new MaskFormatter("##/##/####");
            txtAdmitDate = new JFormattedTextField(dateMask);
        } catch (ParseException e) {
            txtAdmitDate = new JFormattedTextField();
        }
        txtAdmitDate.setBounds(750, 470, 300, 30);
        frame.add(txtAdmitDate);

        lblVaccination = new JLabel("Vaccination:");
        lblVaccination.setBounds(550, 520, 150, 30);
        frame.add(lblVaccination);

        rbVaccYes = new JRadioButton("Yes");
        rbVaccNo = new JRadioButton("No");
        rbVaccYes.setBounds(750, 520, 70, 30);
        rbVaccNo.setBounds(830, 520, 70, 30);
        bgVaccination = new ButtonGroup();
        bgVaccination.add(rbVaccYes);
        bgVaccination.add(rbVaccNo);
        frame.add(rbVaccYes);
        frame.add(rbVaccNo);

        lblDisease = new JLabel("Disease:");
        lblDisease.setBounds(550, 570, 150, 30);
        frame.add(lblDisease);

        rbDiseaseYes = new JRadioButton("Yes");
        rbDiseaseNo = new JRadioButton("No");
        rbDiseaseYes.setBounds(750, 570, 70, 30);
        rbDiseaseNo.setBounds(830, 570, 70, 30);
        bgDisease = new ButtonGroup();
        bgDisease.add(rbDiseaseYes);
        bgDisease.add(rbDiseaseNo);
        frame.add(rbDiseaseYes);
        frame.add(rbDiseaseNo);

        lblDiseaseName = new JLabel("Disease Name:");
        lblDiseaseName.setBounds(550, 620, 150, 30);
        lblDiseaseName.setVisible(false);
        frame.add(lblDiseaseName);

        txtDiseaseName = new JTextField();
        txtDiseaseName.setBounds(750, 620, 300, 30);
        txtDiseaseName.setVisible(false);
        frame.add(txtDiseaseName);

        rbDiseaseYes.addActionListener(e -> {
            lblDiseaseName.setVisible(true);
            txtDiseaseName.setVisible(true);
        });

        rbDiseaseNo.addActionListener(e -> {
            lblDiseaseName.setVisible(false);
            txtDiseaseName.setVisible(false);
        });

        btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(600, 680, 100, 40);
        frame.add(btnSubmit);

        btnBack = new JButton("Back");
        btnBack.setBounds(750, 680, 100, 40);
        frame.add(btnBack);

        btnSubmit.addActionListener(this);
        btnBack.addActionListener(this);

        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSubmit) {
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/animaldata1", "root", "");
                String query = "UPDATE animalinfo1 SET Temperature=?, Heart_Rate=?, Respiration_Rate=?, Body_Condition=?, Coat_Skin=?, Hydration_Level=?, Admit_Date=?, Vaccination=?, Disease=?, Disease_Name=? WHERE Animal_Id=?";
                PreparedStatement pstmt = con.prepareStatement(query);
                pstmt.setInt(1, Integer.parseInt(txtTemperature.getText()));
                pstmt.setInt(2, Integer.parseInt(txtHeartRate.getText()));
                pstmt.setInt(3, Integer.parseInt(txtRespirationRate.getText()));
                pstmt.setString(4, cbBodyCondition.getSelectedItem().toString());
                pstmt.setString(5, cbCoatSkin.getSelectedItem().toString());
                pstmt.setInt(6, Integer.parseInt(txtHydrationLevel.getText()));
                pstmt.setString(7, txtAdmitDate.getText());
                pstmt.setString(8, rbVaccYes.isSelected() ? "Yes" : "No");
                pstmt.setString(9, rbDiseaseYes.isSelected() ? "Yes" : "No");
                pstmt.setString(10, rbDiseaseYes.isSelected() ? txtDiseaseName.getText() : "N/A");
                pstmt.setString(11, txtAnimalId.getText());
                pstmt.executeUpdate();
                int result = pstmt.executeUpdate();
                JOptionPane.showMessageDialog(null, result > 0 ? "Health Entry Submitted Successfully!" : "Insertion Failed!", "Status", JOptionPane.INFORMATION_MESSAGE);
                con.close();
                txtAnimalId.setText("");
                txtTemperature.setText("");
                txtHeartRate.setText("");
                txtRespirationRate.setText("");
                txtHydrationLevel.setText(""); 
                txtDiseaseName.setText("");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == btnBack) {
            frame.dispose();
        }
    }

    public static void main(String[] args) {
        new HealthInsert();
    }
}
